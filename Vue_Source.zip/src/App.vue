<template>
    <div id="app">

 <nav>
        <router-link class="btn btn-primary" to="/">Bank</router-link> |
 </nav>

<div>
        <router-view/>
</div>
</div>

</template>

<script>

export default {
  name: "app",
};
</script>

<style>
.navi {list-style-type: none }
.navi li {display: inline-block; text-decoration: none }
.logout{background-color: blue; color: burlywood}
</style>
