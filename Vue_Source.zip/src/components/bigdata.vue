<template>

<div>

	<section id="intro" class="main">
						<span class="icon fa-diamond major"></span>
						<h2>Hey Man~! Register Your Information</h2>
					</section>
					<section class="main items">
						<article class="item">
							<header>
								<a href="#"><img src="images/big2.jpg" alt="" /></a>
								<h3>Big Data</h3>
							</header>
							
							<table class="">
<colgroup>
		<col style="width:50%;" />
		<col style="width:50%;" />							
</colgroup>	

<tr>
<th>Loan ID</th>
<td><input data-msg="1" type="text" name="title"  id="_title" size="20" v-model="loan_id" /></td>
</tr>
<tr>
<th>Customer ID</th>
<td><input data-msg="2" type="text" name="writer"  id="_writer" size="20" v-model="customer_id"/></td>
</tr>
<tr>
<th>Current Loan Amount</th>
<td><input data-msg="3" type="text" name="writer"  id="_writer" size="20" v-model="current_loan_amount"/></td>
</tr>
<tr>
<th>Term</th>
<td><select v-model="term">
  <option>Short Term</option>
  <option>Long Term</option>
</select></td>
</tr>
<tr>
<th>Credit Score</th>
<td><input data-msg="5" type="text" name="writer"  id="_writer" size="20" v-model="credit_score" /></td>
</tr>
<tr>
<th>Annual Income</th>
<td><input data-msg="6" type="text" name="writer"  id="_writer" size="20" v-model="annual_income"/></td>
</tr>
<tr>
<th>Years in current job</th>
<td><select v-model="years_in_current_job">
  <option>1 year</option>
  <option>2 years</option>
  <option>3 years</option>
  <option>4 years</option>
  <option>5 years</option>
  <option>6 years</option>
  <option>7 years</option>
  <option>8 years</option>
  <option>9 years</option>
  <option>10+ years</option>
</select></td>
</tr>
<tr>
<th>Home Ownership</th>
<td><select v-model="home_ownership">
  <option>Home Mortgage</option>
  <option>Own Home</option>
  <option>Rent</option>
  <option>HaveMortgage</option>
</select></td>
</tr>
<tr>
<th>Purpose</th>
<td><select v-model="purpose">
  <option>Debt Consolidation</option>
  <option>Buy House</option>
  <option>Home Improvements</option>
</select></td>
</tr>
</table>


						</article>
						<article class="item">
							<header>
								<a href="#"><img src="images/big1.jpg" alt="" /></a>
								<h3>Big Data</h3>
							</header>
							
							<table class="">
<colgroup>
		<col style="width:50%;" />
		<col style="width:50%;" />							
</colgroup>	
<tr>
<th>Monthly Debt</th>
<td><input data-msg="10" type="text" name="writer"  id="_writer" size="20" v-model="monthly_dept" /></td>
</tr>
<tr>
<th>Years of Credit History</th>
<td><input data-msg="11" type="text" name="writer"  id="_writer" size="20" v-model="years_of_credit_history" /></td>
</tr>
<tr>
<th>Months since last delinquent</th>
<td><input data-msg="12" type="text" name="writer"  id="_writer" size="20" v-model="months_since_last_delinquent" /></td>
</tr>
<tr>
<th>Number of Open Accounts</th>
<td><input data-msg="13" type="text" name="writer"  id="_writer" size="20" v-model="number_of_open_accounts" /></td>
</tr>
<tr>
<th>Number of Credit Problems</th>
<td><input data-msg="14" type="text" name="writer"  id="_writer" size="20" v-model="number_of_credit_problems" /></td>
</tr>
<tr>
<th>Current Credit Balance</th>
<td><input data-msg="15" type="text" name="writer"  id="_writer" size="20" v-model="current_credit_balance" /></td>
</tr>
<tr>
<th>Maximum Open Credit</th>
<td><input data-msg="16" type="text" name="writer"  id="_writer" size="20" v-model="maximum_open_credit" /></td>
</tr>
<tr>
<th>Bankruptcies</th>
<td><input data-msg="17" type="text" name="writer"  id="_writer" size="20" v-model="bankruptcies" /></td>
</tr>
<tr>
<th>Tax Liens</th>
<td><input data-msg="18" type="text" name="writer"  id="_writer" size="20" v-model="tax_liens" /></td>
</tr>
</table>


						</article>
						
					</section>
<section id="cta" class="main special">
						<ul class="actions">
							<li><button @click="addBoard()" class="button big">Predict</button></li>
						</ul>
					</section>
					<section id="cta" class="main special">
						<ul class="actions">
							<li><h1>Your Loan Status : {{result}}</h1></li>
						</ul>
					</section>
					<footer id="footer">
						<ul class="icons">
							<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
							<li><a href="#" class="icon fa-linkedin"><span class="label">LinkedIn</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
						</ul>
						<p class="copyright">&copy; Untitled. Design: <a href="https://templated.co">TEMPLATED</a>. Images: <a href="https://unsplash.com">Unsplash</a>.</p>
					</footer>

</div>

</template>

<script>
/*jslint devel: true */
/* eslint-disable no-console */
import http from "../http-common";

export default {
	name: "add-board",
	data() {
		return {
		result:'',
		loan_id: '',
		customer_id: '',
		current_loan_amount: '',
		term: '',
		credit_score: '',
		annual_income: '',
		years_in_current_job: '',
		home_ownership: '',
		purpose: '',
		monthly_dept: '',
		years_of_credit_history: '',
		months_since_last_delinquent: '',
		number_of_open_accounts: '',
		number_of_credit_problems: '',
		current_credit_balance: '',
		maximum_open_credit: '',
		bankruptcies: '',
		tax_liens: ''
		};
	},
	filters: {
		salarydecimal (value) {
			var a=parseInt(value);
			return a.toFixed(2);
		}
	}, 
	mounted () {
	},
	methods: {
	addBoard() {
		let senddata = new FormData();
		senddata.append("loan_id",this.loan_id);
		senddata.append("customer_id",this.customer_id);
		senddata.append("current_loan_amount",this.current_loan_amount);
		senddata.append("term",this.term);
		senddata.append("credit_score",this.credit_score);
		senddata.append("annual_income",this.annual_income);
		senddata.append("years_in_current_job",this.years_in_current_job);
		senddata.append("home_ownership",this.home_ownership);
		senddata.append("purpose",this.purpose);
		senddata.append("monthly_dept",this.monthly_dept);
		senddata.append("years_of_credit_history",this.years_of_credit_history);
		senddata.append("months_since_last_delinquent",this.months_since_last_delinquent);
		senddata.append("number_of_open_accounts",this.number_of_open_accounts);
		senddata.append("number_of_credit_problems",this.number_of_credit_problems);
		senddata.append("current_credit_balance",this.current_credit_balance);
		senddata.append("maximum_open_credit",this.maximum_open_credit);
		senddata.append("bankruptcies",this.bankruptcies);
		senddata.append("tax_liens",this.tax_liens);
		// {
		// 	title: this.ctitle,
		// 	contents: this.ccontents,
		// 	writer: this.cwriter
		// }
		http.post('/add',senddata )
		.then(res=>{this.result=res.data});
	}
  }
}
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>
