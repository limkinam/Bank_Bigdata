import Vue from "vue";
import Router from "vue-router";
import bigdata from "./components/bigdata.vue";
//import CustomerRegistry from "./components/CustomerRegistry.vue";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: '/',
      name: 'detailfood',
      component: bigdata,
      props: true,
    },
  ]
});