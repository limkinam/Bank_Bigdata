import axios from "axios";

export default axios.create({
  //baseURL: "http://192.168.28.129:8197/ssafyvue/api",
  baseURL: "http://127.0.0.1:5000/",
  headers: {
    "Content-type": "application/json"
  }
});